import javax.swing.*;
import java.awt.*;

class RobotCanvas extends Canvas {
    public void paint(Graphics g) {

        setBackground(Color.LIGHT_GRAY);

        g.setColor(Color.RED);

        g.drawRect(150, 100, 200, 120);

        g.drawOval(120, 130, 30, 30); 
        g.drawOval(350, 130, 30, 30); 

        g.setColor(Color.RED);
        g.fillOval(180, 130, 30, 30);
        g.fillOval(240, 130, 30, 30); 

        g.setColor(Color.RED);
        g.drawArc(200, 160, 60, 30, 0, -180); // Smiley arc
    }
}

public class RobotFace {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Robot Face Drawing");
        frame.setSize(500, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        RobotCanvas canvas = new RobotCanvas();
        frame.add(canvas);

        frame.setVisible(true);
    }
}