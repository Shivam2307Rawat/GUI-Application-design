import javax.swing.*;
import java.awt.event.*;

public class UserDetailsForm {
    public static void main(String[] args) {

        JFrame frame = new JFrame("User Details Form");
        frame.setSize(450, 300);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JLabel nameLabel = new JLabel("Enter your name:");
        nameLabel.setBounds(30, 30, 150, 25);
        nameLabel.setFont(nameLabel.getFont().deriveFont(14f));

        JTextField nameField = new JTextField();
        nameField.setBounds(180, 30, 200, 25);
        nameField.setFont(nameField.getFont().deriveFont(14f));


        JLabel genderLabel = new JLabel("Select gender:");
        genderLabel.setBounds(30, 70, 150, 25);
        genderLabel.setFont(genderLabel.getFont().deriveFont(14f));

        JRadioButton maleBtn = new JRadioButton("Male");
        maleBtn.setBounds(180, 70, 80, 25);

        JRadioButton femaleBtn = new JRadioButton("Female");
        femaleBtn.setBounds(260, 70, 100, 25);

        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleBtn);
        genderGroup.add(femaleBtn);

        JLabel drinkLabel = new JLabel("What do you like?");
        drinkLabel.setBounds(30, 110, 150, 25);
        drinkLabel.setFont(drinkLabel.getFont().deriveFont(14f));

        JCheckBox coffeeCheck = new JCheckBox("Coffee");
        coffeeCheck.setBounds(180, 110, 80, 25);

        JCheckBox teaCheck = new JCheckBox("Tea");
        teaCheck.setBounds(260, 110, 80, 25);

        JButton submitButton = new JButton("Submit Details");
        submitButton.setBounds(150, 160, 150, 35);

        JLabel resultLabel = new JLabel("");
        resultLabel.setBounds(30, 210, 400, 25);
        resultLabel.setFont(resultLabel.getFont().deriveFont(14f));

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                if (name.isEmpty()) {
                    resultLabel.setText("Please enter your name.");
                    return;
                }

                String title = "";
                if (maleBtn.isSelected()) {
                    title = "Mr.";
                } else if (femaleBtn.isSelected()) {
                    title = "Ms.";
                } else {
                    resultLabel.setText("Please select a gender.");
                    return;
                }

                StringBuilder message = new StringBuilder(title + " " + name);

                if (coffeeCheck.isSelected()) {
                    message.append(" likes coffee");
                }

                if (teaCheck.isSelected()) {
                    if (coffeeCheck.isSelected()) {
                        message.append(", likes tea");
                    } else {
                        message.append(" likes tea");
                    }
                }

                if (!coffeeCheck.isSelected() && !teaCheck.isSelected()) {
                    message.append(" doesn't like coffee or tea");
                }

                message.append(".");

                resultLabel.setText(message.toString());
            }
        });

        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(genderLabel);
        frame.add(maleBtn);
        frame.add(femaleBtn);
        frame.add(drinkLabel);
        frame.add(coffeeCheck);
        frame.add(teaCheck);
        frame.add(submitButton);
        frame.add(resultLabel);

        frame.setVisible(true);
    }
}