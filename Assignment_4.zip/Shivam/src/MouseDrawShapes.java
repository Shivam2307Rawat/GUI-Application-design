import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class DrawingCanvas extends Canvas {
    private java.util.List<Point> points = new ArrayList<>();

    public DrawingCanvas() {
        // Add Mouse Motion Adapter
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                points.add(e.getPoint());
                repaint(); // repaint after each mouse drag
            }
        });
    }

    public void paint(Graphics g) {
        setBackground(Color.WHITE);
        g.setColor(Color.BLUE);

        // Draw a small filled circle at every recorded point
        for (Point p : points) {
            g.fillOval(p.x, p.y, 8, 8); // small circles
        }
    }
}

public class MouseDrawShapes {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Draw with Mouse");
        frame.setSize(600, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        DrawingCanvas canvas = new DrawingCanvas();
        frame.add(canvas);

        frame.setVisible(true);
    }
}
