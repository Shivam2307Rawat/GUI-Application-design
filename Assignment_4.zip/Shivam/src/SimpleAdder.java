import javax.swing.*;
import java.awt.event.*;

public class SimpleAdder {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Simple Adder");
        frame.setSize(400, 300);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel label1 = new JLabel("Enter number 1:");
        label1.setBounds(50, 40, 150, 30);
        label1.setFont(label1.getFont().deriveFont(16f));

        JTextField field1 = new JTextField();
        field1.setBounds(200, 40, 120, 30);
        field1.setFont(field1.getFont().deriveFont(16f));

        JLabel label2 = new JLabel("Enter number 2:");
        label2.setBounds(50, 90, 150, 30);
        label2.setFont(label2.getFont().deriveFont(16f));

        JTextField field2 = new JTextField();
        field2.setBounds(200, 90, 120, 30);
        field2.setFont(field2.getFont().deriveFont(16f));

        JButton addButton = new JButton("+");
        addButton.setBounds(160, 140, 60, 40);
        addButton.setFont(addButton.getFont().deriveFont(18f));

        JLabel resultLabel = new JLabel("Result: ");
        resultLabel.setBounds(50, 200, 300, 30);
        resultLabel.setFont(resultLabel.getFont().deriveFont(18f));

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int num1 = Integer.parseInt(field1.getText());
                    int num2 = Integer.parseInt(field2.getText());
                    int sum = num1 + num2;
                    resultLabel.setText("Result: " + sum);
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input! Please enter integers.");
                }
            }
        });

        frame.add(label1);
        frame.add(field1);
        frame.add(label2);
        frame.add(field2);
        frame.add(addButton);
        frame.add(resultLabel);

        frame.setVisible(true);
    }
}